import logging
from kafka import KafkaProducer
import uvicorn
from fastapi import FastAPI, Request
import json
from typing import Dict

app = FastAPI()

Producer = KafkaProducer(
            bootstrap_servers=['localhost:9095'],
                acks=1,
    value_serializer=lambda v: json.dumps(v, default=str).encode("ascii"),
    api_version=(0, 10, 1)
        )
                         
@app.post("/api/fetch/moisturemate_data")
async def collect_moisture_mate_data(request: Request):
    try:
    	received_data = await request.json()
    	print(f"Received MoistureMate Data: {received_data}")
    except :
    	print("data not received")
    	r = Producer.send('my-topic-1', value={"Msg ID",Dict[received_data]})
    	print(r)
    try:
    	r = Producer.send('my-topic-1', value={"Msg ID",Dict[received_data]})
    	print(r)
    except:
    	print("not sent")
    #return #{"msg": "received moisture_mate data"}


@app.post("/api/fetch/carbonsense_data")
async def collect_carbonsense_data(request: Request):
    received_data = await request.json()
    print(f"Received carbonsense Data: {received_data}")
    return {"msg": "received carbonsense data"}


def run_app():
    logging.basicConfig(level=logging.INFO)
    uvicorn.run(app, host="0.0.0.0", port=3001)


if __name__ == "__main__":
    run_app()
